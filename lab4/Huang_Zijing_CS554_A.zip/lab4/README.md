# React Lecture Code

1. Clone code
2. Run `npm install`
3. Run `gulp` to watch code for JSX Changes
4. Enjoy programming!