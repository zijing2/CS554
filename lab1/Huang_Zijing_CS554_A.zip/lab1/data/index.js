const tasksData = require("./tasks");
const commentsData = require("./comments");

module.exports = {
    tasks: tasksData,
    comments: commentsData
};