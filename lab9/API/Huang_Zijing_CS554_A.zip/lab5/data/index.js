const dbData = require("./db");

module.exports = {
    db: dbData,
};