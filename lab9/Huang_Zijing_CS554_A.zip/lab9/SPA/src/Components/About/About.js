import React from 'react';

export const About = () => (
  <div>
    <h2>About</h2>
  </div>
)
